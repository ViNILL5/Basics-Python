with open('nginx_logs.txt', 'r', encoding='utf-8') as file_1:
  for line in file_1:
    log_lst = line.split()
    log_lst[5] = log_lst[5].replace('"', '')
    result = f"('{log_lst[0]}', '{log_lst[5]}', '{log_lst[6]}')"
    print(result)
