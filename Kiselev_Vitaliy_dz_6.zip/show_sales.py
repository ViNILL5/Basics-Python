summa_lst = []

with open('bakery.csv', 'r', encoding='utf-8') as f:
  for line in f:
    summa_lst.append(line)

def show_sale():
  try:
    a, b = map(int, input('Введите число или диапазон: ').split())
    print(summa_lst[a-1:b-1])
  except ValueError:
    print(summa_lst)
  

show_sale()


if __name__ == '__main__':
  import sys

  exit()