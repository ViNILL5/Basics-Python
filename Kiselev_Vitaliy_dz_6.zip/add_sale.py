import csv

summa_lst = []


def add_sale():
    summa = float(input('Введите число: '))
    return summa_lst.append(summa)

add_sale()

with open('bakery.csv', 'a') as f:
    write = csv.writer(f)
    write.writerow(summa_lst)

if __name__ == '__main__':
    import sys

    exit()
