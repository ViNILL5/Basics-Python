from itertools import zip_longest


FILENAME_USER = 'users.csv'
FILENAME_HOBBY = 'hobby.csv'
FILENAME = 'users_hobby.csv'


with open(FILENAME_USER, 'r') as f:
  temp1 = f.read()
  
with open(FILENAME_HOBBY, 'r') as f:
  temp2 = f.read()

print(temp1)
temp1 = temp1.split('\n')


temp2 = temp2.split('\n')


gen_users_dict = dict(zip_longest(temp1, temp2))
 

with open(FILENAME, 'w') as f:
  for key in gen_users_dict.keys():
    f.write("%s,%s\n"%(key,gen_users_dict[key]))